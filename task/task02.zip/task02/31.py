# Write a Python program to calculate the area of a circle.

import math

radius = int(input("Enter the radius of the circle: "))
area = math.pi * radius * radius
print("The area of the circle is:", area)
