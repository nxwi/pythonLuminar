# Write a program to find the square root of a number.

import math

number = int(input("Enter a number: "))
square_root = math.sqrt(number)
print("The square root of", number, "is", square_root)
