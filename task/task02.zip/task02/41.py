# Write a program to reverse a list in Python.

list1 = input("Enter a list of integers separated by spaces: ").split()
reversed_list = list1[::-1]
print("Reversed list:", reversed_list)
