# Create a program that calculates the area of a triangle.

base = float(input("Enter the base of the triangle: "))
height = float(input("Enter the height of the triangle: "))
area = (base * height) / 2
print("Area of the triangle:", area)
