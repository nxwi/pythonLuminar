# Create a program to print the ASCII value of a character.

character = input("Enter a character: ")
ascii_value = ord(character)
print("ASCII value of", character, ":", ascii_value)
