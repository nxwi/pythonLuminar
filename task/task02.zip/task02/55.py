# Write a Python program to calculate the volume of a sphere.

import math

radius = float(input("Enter the radius of the sphere: "))

volume = (4/3) * math.pi * radius**3

print("Volume of the sphere:", volume)
